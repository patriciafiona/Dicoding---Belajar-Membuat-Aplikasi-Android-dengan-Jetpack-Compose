package com.patriciafiona.subway.data

import com.patriciafiona.subway.data.source.DataSource
import com.patriciafiona.subway.model.Category
import com.patriciafiona.subway.model.News
import com.patriciafiona.subway.model.OrderItem
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map

class SubwayRepository {
//    private val topRatedFoodById = arrayListOf()
    private val promotions = mutableListOf<Int>()
    private val categories = mutableListOf<Category>()
    private val news = mutableListOf<News>()

    init {
        if (promotions.isEmpty()) {
            DataSource.promotions().forEach {
                promotions.add(it)
            }
        }

        if (categories.isEmpty()) {
            DataSource.categories().forEach {
                categories.add(it)
            }
        }

        if (news.isEmpty()) {
            DataSource.news().forEach {
                news.add(it)
            }
        }
    }

    fun getAllPromotions(): Flow<List<Int>> {
        return flowOf(promotions)
    }

    fun getAllCategories(): Flow<List<Category>> {
        return flowOf(categories)
    }

    fun getNews(): Flow<List<News>> {
        return flowOf(news)
    }

    companion object {
        @Volatile
        private var instance: SubwayRepository? = null

        fun getInstance(): SubwayRepository =
            instance ?: synchronized(this) {
                SubwayRepository().apply {
                    instance = this
                }
            }
    }
}