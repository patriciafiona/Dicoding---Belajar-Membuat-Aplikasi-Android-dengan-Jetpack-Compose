package com.patriciafiona.subway.model

data class News(
    val title: String,
    val description: String,
    val image_url: String,
    val news_url: String

)