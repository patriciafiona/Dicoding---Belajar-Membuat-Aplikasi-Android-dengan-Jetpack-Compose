package com.patriciafiona.subway

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.*
import androidx.compose.material.SnackbarDefaults.backgroundColor
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.patriciafiona.subway.navigation.NavigationBuilder
import com.patriciafiona.subway.navigation.SubwayScreen


@Composable
fun SubwayApp(
    navController: NavHostController = rememberNavController(),
) {
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    Scaffold(
        topBar = {
            if (currentRoute != SubwayScreen.DetailScreen.route) {
                TopBar()
            }
        },
        modifier = Modifier
    ) { innerPadding ->
        NavigationBuilder(
            modifier = Modifier.padding(innerPadding)
        )
    }
}

@Composable
fun TopBar() {
    TopAppBar (
        title = {
            Image(
                painter = painterResource(id = R.drawable.logo),
                contentDescription = "logo",
                modifier = Modifier.height(30.dp)
            )
        },
        actions = {
            Row {
               IconButton(onClick = {  }) {
                   Icon(
                       imageVector = Icons.Default.ShoppingCart,
                       contentDescription = "Cart"
                   )
               }
                IconButton(onClick = {  }) {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = "Person Profile"
                    )
                }
            }
        },
        backgroundColor = MaterialTheme.colors.primary,
        contentColor = Color.White,
        elevation = 10.dp
    )
}
