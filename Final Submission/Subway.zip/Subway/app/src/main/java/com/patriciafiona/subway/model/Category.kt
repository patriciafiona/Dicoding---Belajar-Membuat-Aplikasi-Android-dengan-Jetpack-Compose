package com.patriciafiona.subway.model

data class Category (
    val id: Int,
    val name: String,
    val image: Int
)