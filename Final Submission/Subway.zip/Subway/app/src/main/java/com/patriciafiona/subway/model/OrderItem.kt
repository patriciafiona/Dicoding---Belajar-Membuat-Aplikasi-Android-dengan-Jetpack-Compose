package com.patriciafiona.subway.model

import android.content.ClipData
import java.util.*

data class OrderItem(
    val item: ProductItem,
    val count: Int
)
