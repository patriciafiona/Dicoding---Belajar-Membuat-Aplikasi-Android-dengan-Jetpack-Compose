package com.patriciafiona.subway.ui.screen

import androidx.compose.foundation.layout.Column
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavController

@Composable
fun DetailScreen(navController: NavController, modifier: Modifier) {
    Column(
        modifier = modifier
    ) {

    }
}